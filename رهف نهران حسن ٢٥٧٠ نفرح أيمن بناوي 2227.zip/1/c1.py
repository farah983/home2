import socket

def start_client():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(('127.0.0.1', 9999))

    account_name = input('Enter account name: ')
    pin_code = input('Enter PIN: ')
    client_socket.send(f'{account_name},{pin_code}\n'.encode('utf-8'))

    response = client_socket.recv(1024).decode('utf-8').strip()
    if response == 'Authenticated':
        print('Login successful!')
    else:
        print('Authentication failed!')
        client_socket.close()
        return

    while True:
        print("\nOptions:\n1. Check Balance\n2. Deposit Money\n3. Withdraw Money\n4. Logout")
        user_choice = input("Enter choice: ")

        if user_choice == '1':
            client_socket.send(b'BALANCE\n')
            response = client_socket.recv(1024).decode('utf-8').strip()
            print(response)

        elif user_choice == '2':
            deposit_amount = input('Enter amount to deposit: ')
            client_socket.send(f'DEPOSIT,{deposit_amount}\n'.encode('utf-8'))
            response = client_socket.recv(1024).decode('utf-8').strip()
            print(response)

        elif user_choice == '3':
            withdraw_amount = input('Enter amount to withdraw: ')
            client_socket.send(f'WITHDRAW,{withdraw_amount}\n'.encode('utf-8'))
            response = client_socket.recv(1024).decode('utf-8').strip()
            print(response)

        elif user_choice == '4':
            client_socket.send(b'LOGOUT\n')
            response = client_socket.recv(1024).decode('utf-8').strip()
            print(response)
            break

        else:
            print('Invalid choice, please try again.')

    client_socket.close()

if __name__ == '__main__':
    start_client()