import socket
import threading

# حسابات البنك المحددة مسبقاً (اسم الحساب -> (الرقم السري، الرصيد))
bank_accounts = {
    'farah': ('2227', 5000),
    'rahaf': ('2570', 2000),
}

def handle_connection(client_socket):
    try:
        is_authenticated = False
        user_account = None

        while True:
            data = client_socket.recv(1024).decode('utf-8').strip()
            if not data:
                break

            if not is_authenticated:
                user_account, pin_code = data.split(',')
                if user_account in bank_accounts and bank_accounts[user_account][0] == pin_code:
                    is_authenticated = True
                    client_socket.send(b'Authenticated\n')
                else:
                    client_socket.send(b'Authentication Failed\n')
                    break
            else:
                command, *params = data.split(',')

                if command == 'BALANCE':
                    balance = bank_accounts[user_account][1]
                    client_socket.send(f'Balance: {balance}\n'.encode('utf-8'))

                elif command == 'DEPOSIT':
                    deposit_amount = float(params[0])
                    bank_accounts[user_account] = (bank_accounts[user_account][0], bank_accounts[user_account][1] + deposit_amount)
                    client_socket.send(b'Deposit Successful\n')

                elif command == 'WITHDRAW':
                    withdraw_amount = float(params[0])
                    if bank_accounts[user_account][1] >= withdraw_amount:
                        bank_accounts[user_account] = (bank_accounts[user_account][0], bank_accounts[user_account][1] - withdraw_amount)
                        client_socket.send(b'Withdrawal Successful\n')
                    else:
                        client_socket.send(b'Insufficient Funds\n')

                elif command == 'LOGOUT':
                    final_balance = bank_accounts[user_account][1]
                    client_socket.send(f'Final Balance: {final_balance}\n'.encode('utf-8'))
                    break
    finally:
        client_socket.close()

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind(('0.0.0.0', 9999))
    server_socket.listen(5)
    print('Server listening on port 9999')

    while True:
        client_socket, address = server_socket.accept()
        print(f'Accepted connection from {address}')
        client_thread = threading.Thread(target=handle_connection, args=(client_socket,))
        client_thread.start()

if __name__ == '__main__':
    start_server()